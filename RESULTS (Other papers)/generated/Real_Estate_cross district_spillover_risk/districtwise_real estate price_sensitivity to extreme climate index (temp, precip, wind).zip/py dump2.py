import os
import zipfile
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import xarray as xr

# Define latitude and longitude pairs for regions
region_coords = {
    'Sheung Wan': (22.286394, 114.149139),
    'Central': (22.2819, 114.1579),
    'Wan Chai / Causeway Bay': (22.2770, 114.1799),
    'North Point / Quarry Bay': (22.2880, 114.2000),
    'Tsim Sha Tsui': (22.2960, 114.1694),
    'Yau Ma Tei / Mong Kok': (22.3193, 114.1691),
    'Kowloon Bay / Kwun Tong': (22.3125, 114.2217)
}


# Define output base directory under /mnt/data
base_output_dir = "/content/drive/MyDrive/wd/prop data2"

def load_climate_data(lat, lon):
    # Define paths to the NetCDF files
    pr_file_path = '/content/drive/MyDrive/wd/geotry/esmvaltool_tutorial/climate_data/cmip5/output1/MPI-M/MPI-ESM-MR/historical/day/atmos/day/r1i1p1/v20120503/pr_day_MPI-ESM-MR_historical_r1i1p1_20000101-20051231.nc'
    sfcwind_file_path = '/content/drive/MyDrive/wd/geotry/esmvaltool_tutorial/climate_data/cmip5/output1/MPI-M/MPI-ESM-MR/historical/day/atmos/day/r1i1p1/v20120503/sfcWind_day_MPI-ESM-MR_historical_r1i1p1_20000101-20051231.nc'
    tasmax_file_path = '/content/drive/MyDrive/wd/geotry/esmvaltool_tutorial/climate_data/cmip5/output1/MPI-M/MPI-ESM-MR/historical/day/atmos/day/r1i1p1/v20120503/tasmax_day_MPI-ESM-MR_historical_r1i1p1_20000101-20051231.nc'
    tasmin_file_path = '/content/drive/MyDrive/wd/geotry/esmvaltool_tutorial/climate_data/cmip5/output1/MPI-M/MPI-ESM-MR/historical/day/atmos/day/r1i1p1/v20120503/tasmin_day_MPI-ESM-MR_historical_r1i1p1_20000101-20051231.nc'

    # Load each dataset
    sfcwind_ds = xr.open_dataset(sfcwind_file_path)
    tasmax_ds = xr.open_dataset(tasmax_file_path)
    tasmin_ds = xr.open_dataset(tasmin_file_path)

    lat = lat 
    lon = lon

    # Average over latitude and longitude to get a single value per time point
    sfcwind_spatial_avg = sfcwind_ds['sfcWind'].mean(dim=['lat', 'lon'])
    tasmax_spatial_avg = tasmax_ds['tasmax'].mean(dim=['lat', 'lon'])
    tasmin_spatial_avg = tasmin_ds['tasmin'].mean(dim=['lat', 'lon'])

    # Resample to monthly averages
    sfcwind_monthly_avg = sfcwind_spatial_avg.resample(time='ME').mean()
    tasmax_monthly_avg = tasmax_spatial_avg.resample(time='ME').mean()
    tasmin_monthly_avg = tasmin_spatial_avg.resample(time='ME').mean()

    # Convert to pandas DataFrame
    df_sfcwind = sfcwind_monthly_avg.to_dataframe().reset_index()
    df_tasmax = tasmax_monthly_avg.to_dataframe().reset_index()
    df_tasmin = tasmin_monthly_avg.to_dataframe().reset_index()

    # Merge all monthly DataFrames on time
    df_climate_monthly = df_sfcwind.merge(df_tasmax, on='time').merge(df_tasmin, on='time')

    # Reset index to make 'time' a column
    df_climate_monthly.reset_index(inplace=True)
    df_climate_monthly['year_month'] = df_climate_monthly['time'].dt.to_period('M')
    df_climate_monthly.drop(columns=['time'], inplace=True)

    print(df_climate_monthly.shape)

    return df_climate_monthly

def load_property_data():
    # Load property data
    re_df = pd.read_csv('/content/drive/MyDrive/wd/prop data/2.1M.csv', skiprows=1)
    re_df['date_column'] = pd.to_datetime(re_df['Month'], errors='coerce')  # Replace 'date_column' with the actual name
    re_df['year_month'] = re_df['date_column'].dt.to_period('M')
    print(re_df)
    return re_df

def analyze_region(region, df_merged):
    region_name = region.split()[-1]  # Get the last part of the region name for simplicity
    region_output_dir = os.path.join(base_output_dir, region_name)
    os.makedirs(region_output_dir, exist_ok=True)

    # Prepare the subset for analysis
    df_numeric_subset = df_merged[[region, 'tasmax', 'sfcWind', 'tasmin']]
    df_numeric_subset.rename(columns={region: 'PropertyData'}, inplace=True)
    df_numeric_subset['PropertyData'] = pd.to_numeric(df_numeric_subset['PropertyData'], errors='coerce')

    # Compute correlation matrix
    correlation_matrix = df_numeric_subset.corr()
    correlation_matrix_file = os.path.join(region_output_dir, "correlation_matrix.csv")
    correlation_matrix.to_csv(correlation_matrix_file)

    # Compute covariance matrix
    covariance_matrix = df_numeric_subset.cov()
    covariance_matrix_file = os.path.join(region_output_dir, "covariance_matrix.csv")
    covariance_matrix.to_csv(covariance_matrix_file)

    # Linear regression plot using Seaborn
    plt.figure()
    sns.lmplot(x='tasmax', y='PropertyData', data=df_numeric_subset, aspect=1.5, scatter_kws={'alpha': 0.5})
    plt.title(f'{region_name} vs Tasmax')
    plt.xlabel('Max Temperature (Monthly Average)')
    plt.ylabel(f'{region_name} (Monthly Average)')
    lmplot_file = os.path.join(region_output_dir, "property_vs_tasmax.png")
    plt.savefig(lmplot_file)
    plt.close()

    # Time Series Plot
    plt.figure(figsize=(14, 7))
    plt.plot(df_merged.index, df_merged['tasmax'], label='Tasmax (Monthly Average)')
    plt.plot(df_merged.index, df_merged[region], label=f'{region_name} Property Data')
    plt.title(f'Time Series of Tasmax and {region_name} Property Data')
    plt.xlabel('Date')
    plt.ylabel('Values')
    plt.legend()
    time_series_file = os.path.join(region_output_dir, "time_series_plot.png")
    plt.savefig(time_series_file)
    plt.close()

    # Heatmap of Correlation Matrix
    plt.figure(figsize=(8, 6))
    sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
    plt.title('Correlation Heatmap')
    heatmap_file = os.path.join(region_output_dir, "correlation_heatmap.png")
    plt.savefig(heatmap_file)
    plt.close()

    # Pairplot for All Variables
    sns.pairplot(df_numeric_subset)
    plt.suptitle(f'Pairplot of Climate Variables and {region_name} Property Data', y=1.02)
    pairplot_file = os.path.join(region_output_dir, "pairplot.png")
    plt.savefig(pairplot_file)
    plt.close()

    # Standardize the independent variables for PCA
    X = df_numeric_subset[['tasmax', 'sfcWind', 'tasmin']]
    y = df_numeric_subset['PropertyData']
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Perform PCA
    pca = PCA(n_components=2)
    principal_components = pca.fit_transform(X_scaled)

    # Create DataFrame with principal components
    df_pca = pd.DataFrame(data=principal_components, columns=['PC1', 'PC2'])
    df_pca['PropertyData'] = y.values
    df_pca_file = os.path.join(region_output_dir, "df_pca.csv")
    df_pca.to_csv(df_pca_file, index=False)

    # Plot the principal components
    plt.figure(figsize=(10, 7))
    plt.scatter(df_pca['PC1'], df_pca['PC2'], c=df_pca['PropertyData'], cmap='viridis', alpha=0.5)
    plt.title(f'PCA of Climate Variables with {region_name} Data')
    plt.xlabel('Principal Component 1')
    plt.ylabel('Principal Component 2')
    plt.colorbar(label=f'{region_name} (Monthly Average)')
    plt.grid(True)
    pca_plot_file = os.path.join(region_output_dir, "pca_plot.png")
    plt.savefig(pca_plot_file)
    plt.close()

    # Save explained variance
    explained_variance = {
        'PC1': pca.explained_variance_ratio_[0],
        'PC2': pca.explained_variance_ratio_[1]
    }
    explained_variance_file = os.path.join(region_output_dir, "explained_variance.txt")
    with open(explained_variance_file, 'w') as f:
        for key, value in explained_variance.items():
            f.write(f'Explained variance by {key}: {value:.2f}\n')

def main():
    # Load property data
    property_data = load_property_data()

    for region, coords in region_coords.items():
        lat, lon = coords
        # Load climate data specific to latitude and longitude
        climate_data = load_climate_data(lat, lon)
        # Merge climate data with property data
        df_merged = pd.merge(climate_data, property_data, on='year_month', how='inner')
        df_merged.rename(columns={f'Grade A {region}': region}, inplace=True)
        # Analyze the region
        analyze_region(region, df_merged)

    # Create a zip file of all outputs
    output_zip_file = "/content/drive/MyDrive/wd/prop data2/prop_data2_outputs.zip"
    with zipfile.ZipFile(output_zip_file, 'w') as zipf:
        for root, dirs, files in os.walk(base_output_dir):
            for file in files:
                zipf.write(os.path.join(root, file),
                           os.path.relpath(os.path.join(root, file), base_output_dir))

    # Provide the zip file path
    print("All analysis results have been saved in respective subfolders.")
    print(f"Zip file created: {output_zip_file}")

if __name__ == "__main__":
    main()
